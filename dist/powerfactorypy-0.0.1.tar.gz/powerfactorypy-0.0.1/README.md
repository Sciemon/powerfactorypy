# powerfactorypy
Wrapper around the python API of PowerFactory (power system computation software by DIgSILENT).  
